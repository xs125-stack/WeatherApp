package com.example.weatherupdate;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findViewById(R.id.btnCurrentWeather).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 跳转到当前天气页面
                startActivity(new Intent(MainActivity.this, CurrentWeatherActivity.class));
            }
        });

        findViewById(R.id.btnFutureWeather).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 跳转到未来天气页面
                startActivity(new Intent(MainActivity.this, FutureWeatherActivity.class));
            }
        });

        findViewById(R.id.btnHistoryWeather).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 跳转到历史天气页面
                startActivity(new Intent(MainActivity.this, HistoryWeatherActivity.class));
            }
        });



    }

}