package com.example.weatherupdate;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.volcengine.ark.runtime.model.completion.chat.ChatCompletionRequest;
import com.volcengine.ark.runtime.model.completion.chat.ChatMessage;
import com.volcengine.ark.runtime.model.completion.chat.ChatMessageRole;
import com.volcengine.ark.runtime.service.ArkService;

import java.util.ArrayList;
import java.util.List;

public class ChatActivity extends AppCompatActivity {
    private ArkService arkService;
    private List<ChatMessage> chatMessages;
    private ChatAdapter chatAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.chat_window);

        ListView lvChatMessages = findViewById(R.id.lvChatMessages);
        EditText etChatInput = findViewById(R.id.etChatInput);
        Button btnSend = findViewById(R.id.btnSend);

        // 初始化 ArkService
        String apiKey = "aef45580-e013-4411-998e-02f309d4f139"; // 替换为实际密钥
        arkService = ArkService.builder().apiKey(apiKey).build();

        // 初始化消息列表和适配器
        chatMessages = new ArrayList<>();
        chatAdapter = new ChatAdapter(this, chatMessages);
        lvChatMessages.setAdapter(chatAdapter);

        // 发送消息
        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String userInput = etChatInput.getText().toString().trim();
                if (userInput.isEmpty()) {
                    Toast.makeText(ChatActivity.this, "请输入消息", Toast.LENGTH_SHORT).show();
                    return;
                }

                // 添加用户消息到列表
                ChatMessage userMessage = ChatMessage.builder()
                        .role(ChatMessageRole.USER)
                        .content(userInput)
                        .build();
                chatMessages.add(userMessage);
                chatAdapter.notifyDataSetChanged();

                // 清空输入框
                etChatInput.setText("");

                // 创建聊天请求
                ChatCompletionRequest chatCompletionRequest = ChatCompletionRequest.builder()
                        .model("doubao-1.5-lite-32k-250115") // 替换为实际模型ID
                        .messages(chatMessages)
                        .build();

                // 发送请求
                new Thread(() -> {
                    try {
                        arkService.createChatCompletion(chatCompletionRequest)
                                .getChoices()
                                .forEach(choice -> {
                                    runOnUiThread(() -> {
                                        // 添加模型回复到列表
                                        ChatMessage botMessage = choice.getMessage();
                                        chatMessages.add(botMessage);
                                        chatAdapter.notifyDataSetChanged();
                                    });
                                });
                    } catch (Exception e) {
                        runOnUiThread(() -> Toast.makeText(ChatActivity.this, "请求失败: " + e.getMessage(), Toast.LENGTH_SHORT).show());
                    }
                }).start();
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (arkService != null) {
            arkService.shutdownExecutor();
        }
    }
}