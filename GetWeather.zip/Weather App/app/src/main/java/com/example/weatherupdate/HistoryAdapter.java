package com.example.weatherupdate;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;

public class HistoryAdapter extends ArrayAdapter<String> {
    private Context context;
    private ArrayList<String> historyList;
    private DatabaseHelper databaseHelper;
    private OnDeleteClickListener deleteClickListener;

    public HistoryAdapter(@NonNull Context context, ArrayList<String> historyList, DatabaseHelper databaseHelper, OnDeleteClickListener deleteClickListener) {
        super(context, 0, historyList);
        this.context = context;
        this.historyList = historyList;
        this.databaseHelper = databaseHelper;
        this.deleteClickListener = deleteClickListener;
    }

    public interface OnDeleteClickListener {
        void onDeleteClick(String cityName);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.history_item, parent, false);
        }

        TextView tvCityName = convertView.findViewById(R.id.tvCityName);
        ImageView ivDelete = convertView.findViewById(R.id.ivDelete);

        String city = historyList.get(position);
        tvCityName.setText(city);

        // 设置删除按钮点击事件
        ivDelete.setOnClickListener(v -> {
            if (deleteClickListener != null) {
                deleteClickListener.onDeleteClick(city);
            }
        });

        return convertView;
    }
}