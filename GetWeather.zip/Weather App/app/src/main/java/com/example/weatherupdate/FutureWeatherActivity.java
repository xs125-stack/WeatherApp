package com.example.weatherupdate;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DecimalFormat;
import java.util.ArrayList;

public class FutureWeatherActivity extends AppCompatActivity {
    EditText etCity, etDate;
    TextView tvResult;
    private final String geoUrl = "https://api.openweathermap.org/geo/1.0/direct";
    private final String oneCallUrl = "https://api.openweathermap.org/data/3.0/onecall";
    private final String appid = "50d989b0f5ec4c6fce9b56091e303af6"; // 替换为有效的 API 密钥
    DecimalFormat df = new DecimalFormat("#.##");

    PopupWindow popupWindow;
    ListView lvPopupHistory;
    ArrayList<String> historyList;
    HistoryAdapter historyAdapter;
    DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_future_weather);
        etCity = findViewById(R.id.etCity);
        etDate = findViewById(R.id.etDate);
        tvResult = findViewById(R.id.tvResult);
        dbHelper = DatabaseHelper.getInstance(this);
        historyList = new ArrayList<>();
        historyAdapter = null;

        loadHistory();

        etCity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPopupWindow(v);
            }
        });
        etCity.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    showPopupWindow(v);
                } else if (popupWindow != null && popupWindow.isShowing()) {
                    popupWindow.dismiss();
                }
            }
        });
    }
    private void showPopupWindow(View anchorView) {
        if (popupWindow != null && popupWindow.isShowing()) {
            return;
        }

        // 加载 PopupWindow 的布局
        View popupView = LayoutInflater.from(this).inflate(R.layout.popup_history, null);
        lvPopupHistory = popupView.findViewById(R.id.lvHistory);

        // 使用自定义适配器
        historyAdapter = new HistoryAdapter(this, historyList, dbHelper, new HistoryAdapter.OnDeleteClickListener() {
            @Override
            public void onDeleteClick(String cityName) {
                dbHelper.deleteCity(cityName);
                loadHistory();
                historyAdapter.notifyDataSetChanged();
                Toast.makeText(FutureWeatherActivity.this, "记录已删除", Toast.LENGTH_SHORT).show();
            }
        });
        lvPopupHistory.setAdapter(historyAdapter);

        // 设置点击事件
        lvPopupHistory.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String selectedCity = historyList.get(position);
                etCity.setText(selectedCity);
                popupWindow.dismiss();
            }
        });

        // 获取搜索栏的宽度
        int width = anchorView.getWidth();

        // 创建 PopupWindow，设置宽度为搜索栏宽度，高度固定
        popupWindow = new PopupWindow(popupView, width, 400, true);
        popupWindow.setOutsideTouchable(true);
        popupWindow.setFocusable(true);
        popupWindow.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        // 显示 PopupWindow
        popupWindow.showAsDropDown(anchorView);
    }

    private void loadHistory() {
        historyList.clear();
        historyList.addAll(dbHelper.getAllCities());
        if (historyAdapter != null) {
            historyAdapter.notifyDataSetChanged();
        }
    }
    private void saveCityToHistory(String cityName) {
        if (!cityName.isEmpty() && dbHelper.insertCity(cityName)) {
            loadHistory();
        }
    }
    public void getFutureWeather(View view) {
        String city = etCity.getText().toString().trim();
        String date = etDate.getText().toString().trim();
        if (city.equals("") || date.equals("")) {
            tvResult.setText("City and Date fields cannot be empty!");
        } else {
            saveCityToHistory(city);
            String geoRequestUrl = geoUrl + "?q=" + city + "&limit=1&appid=" + appid;
            StringRequest geoRequest = new StringRequest(Request.Method.GET, geoRequestUrl, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    try {
                        JSONArray jsonArray = new JSONArray(response);
                        if (jsonArray.length() > 0) {
                            JSONObject location = jsonArray.getJSONObject(0);
                            double lat = location.getDouble("lat");
                            double lon = location.getDouble("lon");

                            String weatherRequestUrl = oneCallUrl + "?lat=" + lat + "&lon=" + lon + "&exclude=current,minutely,hourly,alerts&appid=" + appid;
                            StringRequest weatherRequest = new StringRequest(Request.Method.GET, weatherRequestUrl, new Response.Listener<String>() {
                                @Override
                                public void onResponse(String response) {
                                    try {
                                        JSONObject jsonResponse = new JSONObject(response);
                                        JSONArray dailyArray = jsonResponse.getJSONArray("daily");

                                        int dayIndex = Integer.parseInt(date) - 1;
                                        if (dayIndex < 0 || dayIndex >= dailyArray.length()) {
                                            tvResult.setText("Invalid date! Please enter a valid day (1-7).");
                                            return;
                                        }

                                        JSONObject dayWeather = dailyArray.getJSONObject(dayIndex);
                                        double dayTemp = dayWeather.getJSONObject("temp").getDouble("day") - 273.15;
                                        String description = dayWeather.getJSONArray("weather").getJSONObject(0).getString("description");
                                        int humidity = dayWeather.getInt("humidity");
                                        double rainProbability = dayWeather.has("rain") ? dayWeather.optDouble("rain", 0) : 0;

                                        tvResult.setTextColor(Color.rgb(68, 134, 199));
                                        tvResult.setText("Weather on Day " + date + " in " + city + ":\n"
                                                + "Temperature: " + df.format(dayTemp) + " °C\n"
                                                + "Description: " + description + "\n"
                                                + "Humidity: " + humidity + "%\n"
                                                + "Rain Probability: " + df.format(rainProbability) + " mm");
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                        tvResult.setText("Error parsing weather data.");
                                    }
                                }
                            }, new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    Toast.makeText(getApplicationContext(), error.toString().trim(), Toast.LENGTH_SHORT).show();
                                }
                            });

                            RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
                            requestQueue.add(weatherRequest);
                        } else {
                            tvResult.setText("City not found!");
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                        tvResult.setText("Error parsing location data.");
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(getApplicationContext(), error.toString().trim(), Toast.LENGTH_SHORT).show();
                }
            });

            RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
            requestQueue.add(geoRequest);
        }
    }
}