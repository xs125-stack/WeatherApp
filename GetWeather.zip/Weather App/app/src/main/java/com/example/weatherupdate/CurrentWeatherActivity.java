package com.example.weatherupdate;



import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DecimalFormat;
import java.util.ArrayList;

public class CurrentWeatherActivity extends AppCompatActivity {
    EditText etCity;
    TextView tvResult;
    PopupWindow popupWindow;
    ListView lvPopupHistory;
    ArrayList<String> historyList;
    HistoryAdapter historyAdapter;
    DatabaseHelper dbHelper;

    private final String geoUrl = "https://api.openweathermap.org/geo/1.0/direct";
    private final String oneCallUrl = "https://api.openweathermap.org/data/3.0/onecall";
    private final String appid = "50d989b0f5ec4c6fce9b56091e303af6"; // 替换为有效的 API 密钥
    DecimalFormat df = new DecimalFormat("#.##");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_current_weather);
        etCity = findViewById(R.id.etCity);
        tvResult = findViewById(R.id.tvResult);
        dbHelper = DatabaseHelper.getInstance(this);
        historyList = new ArrayList<>();
        historyAdapter = null;

        loadHistory();

        etCity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPopupWindow(v);
            }
        });
        Button btnOpenChat = findViewById(R.id.btnOpenChat);
        btnOpenChat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 打开聊天窗口
                startActivity(new Intent(CurrentWeatherActivity.this, ChatActivity.class));
            }
        });
    }

    private void showPopupWindow(View anchorView) {
        if (popupWindow != null && popupWindow.isShowing()) {
            return;
        }

        // 加载 PopupWindow 的布局
        View popupView = LayoutInflater.from(this).inflate(R.layout.popup_history, null);
        lvPopupHistory = popupView.findViewById(R.id.lvHistory);

        // 使用自定义适配器
        historyAdapter = new HistoryAdapter(this, historyList, dbHelper, new HistoryAdapter.OnDeleteClickListener() {
            @Override
            public void onDeleteClick(String cityName) {
                dbHelper.deleteCity(cityName);
                loadHistory();
                historyAdapter.notifyDataSetChanged();
                Toast.makeText(CurrentWeatherActivity.this, "记录已删除", Toast.LENGTH_SHORT).show();
            }
        });
        lvPopupHistory.setAdapter(historyAdapter);

        // 设置点击事件
        lvPopupHistory.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String selectedCity = historyList.get(position);
                etCity.setText(selectedCity);
                popupWindow.dismiss();
            }
        });

        // 获取搜索栏的宽度
        int width = anchorView.getWidth();

        // 创建 PopupWindow，设置宽度为搜索栏宽度，高度固定
        popupWindow = new PopupWindow(popupView, width, 400, true);
        popupWindow.setOutsideTouchable(true);
        popupWindow.setFocusable(true);

        // 显示 PopupWindow
        popupWindow.showAsDropDown(anchorView);
    }

    public void getWeatherDetails(View view) {
        String city = etCity.getText().toString().trim();
        if (city.isEmpty()) {
            tvResult.setText("城市名称不能为空！");
        } else {
            if (popupWindow != null) {
                popupWindow.dismiss();
            }
            if (dbHelper.insertCity(city)) {
                loadHistory();
            }

            String geoRequestUrl = geoUrl + "?q=" + city + "&limit=1&appid=" + appid;
            StringRequest geoRequest = new StringRequest(Request.Method.GET, geoRequestUrl, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    try {
                        JSONArray jsonArray = new JSONArray(response);
                        if (jsonArray.length() > 0) {
                            JSONObject location = jsonArray.getJSONObject(0);
                            double lat = location.getDouble("lat");
                            double lon = location.getDouble("lon");

                            String weatherRequestUrl = oneCallUrl + "?lat=" + lat + "&lon=" + lon + "&exclude=minutely,hourly,daily,alerts&appid=" + appid;
                            StringRequest weatherRequest = new StringRequest(Request.Method.GET, weatherRequestUrl, new Response.Listener<String>() {
                                @Override
                                public void onResponse(String response) {
                                    try {
                                        JSONObject jsonResponse = new JSONObject(response);
                                        JSONObject current = jsonResponse.getJSONObject("current");
                                        double temp = current.getDouble("temp") - 273.15;
                                        String description = current.getJSONArray("weather").getJSONObject(0).getString("description");
                                        int humidity = current.getInt("humidity");
                                        double rainProbability = current.has("rain") ? current.getJSONObject("rain").optDouble("1h", 0) : 0;
                                        double windSpeed = current.getDouble("wind_speed");
                                        int windDirection = current.getInt("wind_deg");

                                        // 更新显示内容
                                        tvResult.setTextColor(Color.rgb(68, 134, 199));
                                        tvResult.setText("当前天气：" + city + "\n"
                                                + "温度: " + df.format(temp) + " °C\n"
                                                + "描述: " + description + "\n"
                                                + "湿度: " + humidity + "%\n"
                                                + "降雨概率: " + df.format(rainProbability) + " mm\n"
                                                + "风速: " + df.format(windSpeed) + " m/s\n"
                                                + "风向: " + windDirection + "°");
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                        tvResult.setText("解析天气数据时出错。");
                                    }
                                }
                            }, new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    Toast.makeText(getApplicationContext(), error.toString().trim(), Toast.LENGTH_SHORT).show();
                                }
                            });

                            RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
                            requestQueue.add(weatherRequest);
                        } else {
                            tvResult.setText("未找到该城市！");
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                        tvResult.setText("解析位置信息时出错。");
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(getApplicationContext(), error.toString().trim(), Toast.LENGTH_SHORT).show();
                }
            });

            RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
            requestQueue.add(geoRequest);
        }
    }

    private void loadHistory() {
        historyList.clear();
        historyList.addAll(dbHelper.getAllCities());
        if (historyAdapter != null) {
            historyAdapter.notifyDataSetChanged();
        }
    }
}