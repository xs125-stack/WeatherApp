package com.example.weatherupdate;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class HistoryWeather extends AppCompatActivity {

    private ListView lvHistoryWeather;
    private HistoryAdapter historyAdapter;
    private ArrayList<String> historyList;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        lvHistoryWeather = findViewById(R.id.lvHistoryWeather);
        dbHelper = DatabaseHelper.getInstance(this);
        historyList = dbHelper.getAllCities();

        historyAdapter = new HistoryAdapter(this, historyList, dbHelper, new HistoryAdapter.OnDeleteClickListener() {
            @Override
            public void onDeleteClick(String cityName) {
                dbHelper.deleteCity(cityName);
                loadHistory();
                Toast.makeText(HistoryWeather.this, "记录已删除", Toast.LENGTH_SHORT).show();
            }
        });

        lvHistoryWeather.setAdapter(historyAdapter);
    }

    private void loadHistory() {
        historyList.clear();
        historyList.addAll(dbHelper.getAllCities());
        historyAdapter.notifyDataSetChanged();
    }
}