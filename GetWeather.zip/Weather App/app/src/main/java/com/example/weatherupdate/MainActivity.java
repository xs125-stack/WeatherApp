package com.example.weatherupdate;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findViewById(R.id.btnCurrentWeather).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 跳转到当前天气页面
                startActivity(new Intent(MainActivity.this, CurrentWeatherActivity.class));
            }
        });

        findViewById(R.id.btnFutureWeather).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 跳转到未来天气页面
                startActivity(new Intent(MainActivity.this, FutureWeatherActivity.class));
            }
        });

        findViewById(R.id.btnHistoryWeather).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 跳转到历史天气页面
                startActivity(new Intent(MainActivity.this, HistoryWeatherActivity.class));
            }
        });
        findViewById(R.id.btnInfo).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showInfoDialog();
            }
        });
    }

        private void showInfoDialog() {
            // 创建浮窗视图
            View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_info, null);

            // 设置浮窗内容（可以动态修改）
            TextView tvInfo = dialogView.findViewById(R.id.tvInfo);
            tvInfo.setText("Xiang Shi's App; PM Accelerator: A platform to transparently showcase PM skills to ease the application / hiring process for PMs and companies.");

            // 显示浮窗
            new AlertDialog.Builder(this)
                    .setView(dialogView)
                    .setPositiveButton("关闭", null)
                    .show();
        }



    }

