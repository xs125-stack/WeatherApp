package com.example.weatherupdate;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class HistoryWeatherActivity extends AppCompatActivity {
    EditText etCity, etStartDate, etEndDate;
    TextView tvResult;
    private final String historyWeatherUrl = "https://api.openweathermap.org/data/3.0/onecall/timemachine";
    private final String geoUrl = "https://api.openweathermap.org/geo/1.0/direct";
    private final String appid = "50d989b0f5ec4c6fce9b56091e303af6"; // 替换为有效的 API 密钥

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history_weather);
        etCity = findViewById(R.id.etCity);
        etStartDate = findViewById(R.id.etStartDate);
        etEndDate = findViewById(R.id.etEndDate);
        tvResult = findViewById(R.id.tvResult);

        etStartDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePickerDialog(etStartDate);
            }
        });

        // 设置结束日期选择器
        etEndDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePickerDialog(etEndDate);
            }
        });
    }
    private void showDatePickerDialog(EditText targetEditText) {
        // 获取当前日期
        final Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        // 创建 DatePickerDialog
        DatePickerDialog datePickerDialog = new DatePickerDialog(this, (view, selectedYear, selectedMonth, selectedDay) -> {
            // 将选择的日期设置到目标 EditText 中
            String selectedDate = selectedYear + "-" + String.format("%02d", (selectedMonth + 1)) + "-" + String.format("%02d", selectedDay);
            targetEditText.setText(selectedDate);
        }, year, month, day);

        // 显示 DatePickerDialog
        datePickerDialog.show();
    }
    public void getHistoryWeather(View view) {
        String city = etCity.getText().toString().trim();
        String startDateStr = etStartDate.getText().toString().trim();
        String endDateStr = etEndDate.getText().toString().trim();

        if (city.isEmpty() || startDateStr.isEmpty() || endDateStr.isEmpty()) {
            tvResult.setText("All fields are required!");
            return;
        }

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        try {
            Date startDate = sdf.parse(startDateStr);
            Date endDate = sdf.parse(endDateStr);
            Date currentDate = new Date();

            if (startDate.after(currentDate) || endDate.after(currentDate)) {
                tvResult.setText("Dates must be in the past!");
                return;
            }

            if (startDate.after(endDate)) {
                tvResult.setText("Start date must be before end date!");
                return;
            }

            // 获取城市经纬度
            String geoRequestUrl = geoUrl + "?q=" + city + "&limit=1&appid=" + appid;
            StringRequest geoRequest = new StringRequest(Request.Method.GET, geoRequestUrl, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    try {
                        JSONArray jsonArray = new JSONArray(response);
                        if (jsonArray.length() > 0) {
                            JSONObject location = jsonArray.getJSONObject(0);
                            double lat = location.getDouble("lat");
                            double lon = location.getDouble("lon");

                            // 获取历史天气数据
                            fetchHistoryWeather(lat, lon, startDate, endDate);
                        } else {
                            tvResult.setText("City not found!");
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                        tvResult.setText("Error parsing location data.");
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(getApplicationContext(), error.toString().trim(), Toast.LENGTH_SHORT).show();
                }
            });

            RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
            requestQueue.add(geoRequest);

        } catch (ParseException e) {
            tvResult.setText("Invalid date format! Use yyyy-MM-dd.");
        }
    }

    private void fetchHistoryWeather(double lat, double lon, Date startDate, Date endDate) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        StringBuilder result = new StringBuilder();

        // 遍历日期范围
        for (Date date = startDate; !date.after(endDate); date = new Date(date.getTime() + 86400000)) {
            final String currentDateStr = sdf.format(date); // 格式化日期为 YYYY-MM-DD
            String requestUrl = "https://api.openweathermap.org/data/3.0/onecall/day_summary"
                    + "?lat=" + lat
                    + "&lon=" + lon
                    + "&date=" + currentDateStr
                    + "&units=metric" // 使用公制单位（摄氏度）
                    + "&appid=" + appid;

            StringRequest historyRequest = new StringRequest(Request.Method.GET, requestUrl, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    try {
                        JSONObject jsonResponse = new JSONObject(response);
                        String date = jsonResponse.getString("date");
                        JSONObject temperature = jsonResponse.getJSONObject("temperature");
                        double minTemp = temperature.getDouble("min");
                        double maxTemp = temperature.getDouble("max");
                        double afternoonTemp = temperature.getDouble("afternoon");

                        JSONObject humidity = jsonResponse.getJSONObject("humidity");
                        int afternoonHumidity = humidity.getInt("afternoon");

                        JSONObject wind = jsonResponse.getJSONObject("wind").getJSONObject("max");
                        double windSpeed = wind.getDouble("speed");
                        int windDirection = wind.getInt("direction");

                        // 拼接每日天气信息
                        result.append("Date: ").append(date).append("\n")
                                .append("Min Temp: ").append(minTemp).append(" °C\n")
                                .append("Max Temp: ").append(maxTemp).append(" °C\n")
                                .append("Afternoon Temp: ").append(afternoonTemp).append(" °C\n")
                                .append("Afternoon Humidity: ").append(afternoonHumidity).append(" %\n")
                                .append("Wind Speed: ").append(windSpeed).append(" m/s\n")
                                .append("Wind Direction: ").append(windDirection).append("°\n\n");

                        tvResult.setText(result.toString());
                    } catch (JSONException e) {
                        e.printStackTrace();
                        tvResult.setText("Error parsing weather data.");
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(getApplicationContext(), error.toString().trim(), Toast.LENGTH_SHORT).show();
                }
            });

            RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
            requestQueue.add(historyRequest);
        }
    }
}
